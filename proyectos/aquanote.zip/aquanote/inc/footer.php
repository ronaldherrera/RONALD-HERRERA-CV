<?php
// inc/footer.php
?>
<footer>
    <p>Diseñado y desarrollado por <a href="https://ronaldherrera.es/">Ronald Herrera</a> <br>&copy; <?= date('Y') ?> Aquanote. Todos los derechos reservados.</p>
</footer>
</body>
</html>
